package com.online.shopping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebElement;
import static org.junit.Assert.assertEquals;

public class OnlineShopping {

	public static void main(String[] args) throws InterruptedException {
		
		//geckodriver initialization 
		System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");
		
		//Creating object of Firefox Driver
		WebDriver driver = new FirefoxDriver();
		
		//URL specifying 
		driver.get("https://www.saucedemo.com/");
		Thread.sleep(3000);
		
		String login_id = new String("standard_user");
		String password = new String("secret_sauce");
		
		driver.findElement(By.id("user-name")).sendKeys(login_id);
		driver.findElement(By.id("password")).sendKeys(password);
		
		driver.findElement(By.xpath("//input[@class='submit-button btn_action']")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[contains(text(), 'Sauce Labs Bolt T-Shirt')]")).click();
		
		Thread.sleep(2000);
		System.out.println("Product Name -  "+driver.findElement(By.xpath("//*[contains(text(), 'Sauce Labs Bolt T-Shirt')]")).getText());
		System.out.println("Product Description -  "+driver.findElement(By.xpath("//div[@class='inventory_details_desc large_size']")).getText());
		
		System.out.println("Product Price -  "+driver.findElement(By.className("inventory_details_price")).getText());
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[contains(text(),'Add to cart')]")).click();

		WebElement buttonText = driver.findElement(By.xpath("//button[@id='remove-sauce-labs-bolt-t-shirt']"));
		assertEquals("Remove", buttonText.getText()); 
		
		driver.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();
		
		assertEquals("https://www.saucedemo.com/cart.html", driver.getCurrentUrl());
		driver.findElement(By.xpath("//button[@id='checkout']")).click();
		
		assertEquals("https://www.saucedemo.com/checkout-step-one.html", driver.getCurrentUrl());
		
		driver.findElement(By.id("first-name")).sendKeys("Adarsh");
		driver.findElement(By.id("last-name")).sendKeys("Raj");
		driver.findElement(By.id("postal-code")).sendKeys("700135");
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		System.out.println("-----------------------------------------------");
		System.out.println(driver.findElement(By.xpath("(//div[@class=\"summary_info_label\"])[1]")).getText());
		System.out.println(driver.findElement(By.xpath("(//div[@class=\"summary_value_label\"])[1]")).getText());
		System.out.println("-----------------------------------------------");
		System.out.println(driver.findElement(By.xpath("(//div[@class=\"summary_info_label\"])[2]")).getText());
		System.out.println(driver.findElement(By.xpath("(//div[@class=\"summary_value_label\"])[2]")).getText());
		System.out.println("-----------------------------------------------");
		System.out.println(driver.findElement(By.xpath("(//div[@class=\"summary_info_label\"])[3]")).getText());
		System.out.println(driver.findElement(By.xpath("//div[@class=\"summary_subtotal_label\"]")).getText());
		System.out.println(driver.findElement(By.xpath("//div[@class=\"summary_tax_label\"]")).getText());
		
		System.out.println("-----------------------------------------------");
		System.out.println(driver.findElement(By.xpath("//div[@class=\"summary_info_label summary_total_label\"]")).getText());
		System.out.println("-----------------------------------------------");
		System.out.println("\n");
		driver.findElement(By.xpath("//button[@id='finish']")).click();
		
		assertEquals("https://www.saucedemo.com/checkout-complete.html", driver.getCurrentUrl());
		
		WebElement thanksMsg = driver.findElement(By.xpath("//h2[@class='complete-header']"));
		assertEquals("Thank you for your order!", thanksMsg.getText());
		
		System.out.println("-----------------------------------------------");
		System.out.println(thanksMsg.getText());
		System.out.println("-----------------------------------------------");
		
		driver.findElement(By.id("back-to-products")).click();
		
		//Logout actions
		driver.findElement(By.xpath("//div[@class='bm-burger-button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@id='logout_sidebar_link']")).click();
		
		
		//verifying Home Page after logout 
		assertEquals("https://www.saucedemo.com/", driver.getCurrentUrl());
		
		
		//closing the driver
		driver.close();
	}

}



